from django.contrib import admin
from .models import Profile
from dashboard.models import Product, Order

admin.site.site_header = 'Gestion de stock du salon Ebene'


# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display = ('reference', 'name', 'category', 'stock')
    list_filter = ('category',)


# Register admin profiles
admin.site.register(Profile)

admin.site.register(Product, ProductAdmin),
# admin.site.register(Order)
